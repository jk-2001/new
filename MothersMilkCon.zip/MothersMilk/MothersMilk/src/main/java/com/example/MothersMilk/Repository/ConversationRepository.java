package com.example.MothersMilk.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.MothersMilk.model.Conversation;

public interface ConversationRepository extends JpaRepository<Conversation,Integer>{

}
