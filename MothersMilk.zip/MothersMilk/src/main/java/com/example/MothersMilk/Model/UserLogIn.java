package com.example.MothersMilk.Model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.CreationTimestamp;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "MothersGift.Sign_UP")
@AllArgsConstructor
@NoArgsConstructor
@Builder

public class UserLogIn {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id")
    private Integer userId;

    @Column(name = "account_type")
    @NotBlank(message = "Enter Account Type")
    private String accountType;

    @Column(name = "user_name")
    @NotBlank(message = "Enter User Name")
    private String userName;

    @Column(name = "password")
    @NotBlank(message = "Enter Password")
    private String password;

    @Column(name = "aadhaar_no", length = 12)
    @NotBlank(message = "Enter Aadhar_NO")
    private String aadhaarNo;

    @Column(name = "age")
    @NotBlank(message = "Enter Age")
    private Integer age;

    @Column(name = "e_mail")
    @NotBlank(message = "Enter Email")
    private String email;

    @Column(name = "contact", length = 13)
    @NotBlank(message = "Enter Contact")
    private String contact;

    @Column(name = "address")
    @NotBlank(message = "Enter Address")
    private String address;

    @Column(name = "doctors_certificate")
    @NotBlank(message = "Enter Doctors Certificate")
    private String doctorsCertificate; // Assuming you'll store the document path or reference here


    @Column(name = "medical_prescription")
    @NotBlank(message = "Enter Medical Prescription")
    private String medicalPrescription; // Assuming you'll store the document path or reference here

    @CreationTimestamp
    @Column(name = "created_at")
    private Timestamp createdAt;
    @Column(name = "created_by")
    private String createdBy;
}